<?xml version="1.0" encoding="UTF-8"?>
<tileset name="beach_tileset" tilewidth="16" tileheight="16" tilecount="936" columns="36">
 <image source="beach_tileset.png" width="576" height="416"/>
 <tile id="37">
  <animation>
   <frame tileid="37" duration="1000"/>
   <frame tileid="46" duration="1000"/>
   <frame tileid="55" duration="1000"/>
   <frame tileid="64" duration="1000"/>
  </animation>
 </tile>
 <tile id="148">
  <animation>
   <frame tileid="148" duration="1000"/>
   <frame tileid="157" duration="1000"/>
   <frame tileid="166" duration="1000"/>
   <frame tileid="175" duration="1000"/>
  </animation>
 </tile>
</tileset>