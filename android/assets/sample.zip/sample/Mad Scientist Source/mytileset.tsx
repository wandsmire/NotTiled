<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
<tileset firstgid="1" name="tileset" columns="5" tilecount="25" tileheight="16" tilewidth="16">
  <image source="tileset.png" width="80" height="80" />
  <tile id="1">
    <properties>
      <property name="name" value="brick" />
    </properties>
  </tile>
  <tile id="4">
    <properties>
      <property name="name" value="player" />
      <property name="anim" value="plane.png" />
      <property name="stepping" value="" />
    </properties>
  </tile>
  <tile id="7">
    <properties>
      <property name="name" value="brick" />
    </properties>
  </tile>
  <tile id="10">
    <properties>
      <property name="name" value="player" />
      <property name="anim" value="player.png" />
      <property name="size" value="10,14" />
      <property name="HP" value="5" />
      <property name="sfx" value="sfx/player.mp3" />
      <property name="sfxdead" value="sfx/monster.wav" />
    </properties>
  </tile>
  <tile id="5">
    <properties>
      <property name="name" value="brick" />
    </properties>
  </tile>
  <tile id="11">
    <properties>
      <property name="name" value="enemy" />
      <property name="anim" value="enemy.png" />
      <property name="panim" value="shoot.png" />
      <property name="canshoot" value="" />
      <property name="chase" value="" />
      <property name="HP" value="3" />
      <property name="destructible" value="" />
      <property name="sfxdead" value="sfx/monster.wav" />
    </properties>
  </tile>
  <tile id="14">
    <properties>
      <property name="name" value="enemy" />
      <property name="canshoot" value="" />
      <property name="panim" value="shoot.png" />
      <property name="pcooldown" value="0.5" />
      <property name="HP" value="50" />
      <property name="chaseRadius" value="400" />
      <property name="pspread" value="2" />
      <property name="anim" value="enemy.png" />
      <property name="destructible" value="" />
      <property name="xsetvar" value="win=1" />
      <property name="stepping" value="" />
    </properties>
  </tile>
  <tile id="13">
    <properties>
      <property name="name" value="enemy" />
      <property name="panim" value="shoot.png" />
      <property name="canshoot" value="" />
      <property name="dir" value="2" />
      <property name="dirlocked" value="" />
      <property name="heavy" value="" />
      <property name="destructible" value="" />
      <property name="HP" value="3" />
      <property name="sfxdead" value="sfx/monster.wav" />
      <property name="psfx" value="sfx/acp-www.fesliyanstudios.com.mp3" />
    </properties>
  </tile>
  <tile id="12">
    <properties>
      <property name="name" value="enemy" />
      <property name="dir" value="2" />
      <property name="dirlocked" value="" />
      <property name="heavy" value="" />
      <property name="path" value="left,left,right,right" />
      <property name="damage" value="1" />
    </properties>
  </tile>
  <tile id="6">
    <properties>
      <property name="name" value="block" />
      <property name="damage" value="99999" />
    </properties>
  </tile>
  <tile id="19">
    <properties>
      <property name="name" value="item" />
      <property name="load" value="" />
    </properties>
  </tile>
  <tile id="18">
    <properties>
      <property name="name" value="item" />
      <property name="transfer" value="map.tmx" />
      <property name="setvar" value="win=0,defuse=0,energy=100,cave1=0,cave2=0,cave3=0,cave4=0,cave5=0" />
    </properties>
  </tile>
  <tile id="3">
    <properties>
      <property name="name" value="block" />
      <property name="premessage" value="This is the mad scientist lair! but defuse the bombs first!!" />
      <property name="condition" value="defuse=5" />
      <property name="transfer" value="lair.tmx" />
      <property name="message" value="Time for action!" />
    </properties>
  </tile>
  <tile id="15">
    <properties>
      <property name="name" value="item" />
      <property name="save" value="" />
      <property name="restoreHP" value="" />
      <property name="setvar" value="energy=100" />
      <property name="sethud" value="energy" />
      <property name="icon" value="3,0" />
      <property name="keephud" value="" />
      <property name="sfx" value="sfx/checkpoint.wav" />
    </properties>
  </tile>
  <tile id="8">
    <properties>
      <property name="name" value="block" />
      <property name="HP" value="5" />
      <property name="destructible" value="" />
      <property name="sfxdead" value="sfx/brick.wav" />
    </properties>
  </tile>
  <tile id="17">
    <properties>
      <property name="name" value="item" />
      <property name="setvar" value="energy=100" />
      <property name="once" value="" />
      <property name="sfx" value="sfx/coin.wav" />
    </properties>
  </tile>
  <tile id="9">
    <properties>
      <property name="name" value="item" />
      <property name="message" value="Bomb defused!" />
      <property name="addvar" value="defuse=1" />
      <property name="once" value="" />
      <property name="sethud" value="defuse" />
      <property name="keephud" value="" />
      <property name="icon" value="1,4" />
    </properties>
  </tile>
  <tile id="16">
    <properties>
      <property name="name" value="item" />
      <property name="once" value="" />
      <property name="damage" value="-1" />
      <property name="sfx" value="sfx/coin.wav" />
    </properties>
  </tile>
</tileset>