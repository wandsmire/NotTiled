<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Stone Sand - Flat" tilewidth="20" tileheight="20">
 <image source="bitmaps/stone2sand_flat.png" trans="008a76" width="60" height="140"/>
</tileset>
