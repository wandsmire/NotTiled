<?xml version="1.0" encoding="UTF-8"?>
<tileset name="misc" tilewidth="20" tileheight="20" tilecount="18" columns="3">
 <image source="bitmaps/misc.png" width="79" height="120"/>
 <tile id="4">
  <properties>
   <property name="res_pool" value=""/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="team" value="none"/>
   <property name="unit" value="tree"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="team" value="none"/>
   <property name="type" value="1.0"/>
   <property name="unit" value="tree"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="team" value="none"/>
   <property name="type" value="1.1"/>
   <property name="unit" value="tree"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="team" value="none"/>
   <property name="type" value="1.2"/>
   <property name="unit" value="tree"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="team" value="none"/>
   <property name="type" value="1.3"/>
   <property name="unit" value="tree"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="team" value="none"/>
   <property name="type" value="1.4"/>
   <property name="unit" value="tree"/>
  </properties>
 </tile>
</tileset>
