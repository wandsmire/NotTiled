<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Long Grass" tilewidth="20" tileheight="20">
 <image source="bitmaps/longgrass.png" trans="008a76" width="100" height="160"/>
 <tile id="16">
  <properties>
   <property name="trees" value=""/>
  </properties>
 </tile>
</tileset>
