<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Sand Dirt - Ridge" tilewidth="20" tileheight="20">
 <image source="bitmaps/sand2dirt_ridge.png" trans="008a76"/>
</tileset>
